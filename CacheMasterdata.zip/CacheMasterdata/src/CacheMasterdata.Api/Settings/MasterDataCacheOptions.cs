namespace CacheMasterdata.Api.Settings
{
    public class MasterDataCacheOptions
    {
        public int AbsoluteExpirationMinutes { get; set; } = 30;
        public int SlidingExpirationMinutes { get; set; } = 10;
    }
}
