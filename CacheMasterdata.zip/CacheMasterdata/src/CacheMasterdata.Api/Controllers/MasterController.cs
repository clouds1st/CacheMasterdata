using Microsoft.AspNetCore.Mvc;
using CacheMasterdata.Api.Services;
using System.Threading;
using System.Threading.Tasks;

namespace CacheMasterdata.Api.Controllers
{
    [ApiController]
    [Route("api/master")]
    public class MasterController : ControllerBase
    {
        private readonly IMasterDataService _service;

        public MasterController(IMasterDataService service)
        {
            _service = service;
        }

        /// <summary>
        /// Returns list of countries (cached).
        /// </summary>
        [HttpGet("countries")]
        public async Task<IActionResult> GetCountries(CancellationToken ct)
        {
            var data = await _service.GetCountriesAsync(ct);
            return Ok(data);
        }

        /// <summary>
        /// Manually invalidates countries cache.
        /// </summary>
        [HttpPost("countries/invalidate")]
        public async Task<IActionResult> InvalidateCountries()
        {
            await _service.InvalidateCountriesAsync();
            return NoContent();
        }
    }
}
