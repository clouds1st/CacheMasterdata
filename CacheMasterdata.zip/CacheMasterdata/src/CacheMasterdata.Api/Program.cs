using CacheMasterdata.Api.Services;
using CacheMasterdata.Api.Settings;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = WebApplication.CreateBuilder(args);

// Controllers & Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Inbuilt memory cache
builder.Services.AddMemoryCache();

// Bind cache policy from configuration
builder.Services.Configure<MasterDataCacheOptions>(
    builder.Configuration.GetSection("CacheSettings"));

// DI: repository + service
builder.Services.AddScoped<IMasterDataRepository, InMemoryMasterDataRepository>();
builder.Services.AddScoped<IMasterDataService, MasterDataService>();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

app.Run();
