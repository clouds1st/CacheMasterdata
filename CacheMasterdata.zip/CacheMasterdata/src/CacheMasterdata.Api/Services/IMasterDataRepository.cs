using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace CacheMasterdata.Api.Services
{
    /// <summary>
    /// Repository to fetch master data from DB or any external source.
    /// </summary>
    public interface IMasterDataRepository
    {
        Task<List<string>> LoadCountriesAsync(CancellationToken ct = default);
    }
}
