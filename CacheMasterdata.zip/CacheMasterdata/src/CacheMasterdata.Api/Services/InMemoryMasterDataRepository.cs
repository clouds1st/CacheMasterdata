using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace CacheMasterdata.Api.Services
{
    public class InMemoryMasterDataRepository : IMasterDataRepository
    {
        public Task<List<string>> LoadCountriesAsync(CancellationToken ct = default)
        {
            var data = new List<string> { "India", "USA", "UK", "Germany" };
            return Task.FromResult(data);
        }
    }
}
