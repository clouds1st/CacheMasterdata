using CacheMasterdata.Api.Settings;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace CacheMasterdata.Api.Services
{
    public class MasterDataService : IMasterDataService
    {
        private readonly IMemoryCache _cache;
        private readonly IMasterDataRepository _repo;
        private readonly ILogger<MasterDataService> _logger;
        private readonly MasterDataCacheOptions _options;

        private const string CountriesCacheKey = "master:countries";

        public MasterDataService(
            IMemoryCache cache,
            IMasterDataRepository repo,
            ILogger<MasterDataService> logger,
            IOptions<MasterDataCacheOptions> options)
        {
            _cache = cache;
            _repo = repo;
            _logger = logger;
            _options = options.Value ?? new MasterDataCacheOptions();
        }

        public async Task<IReadOnlyList<string>> GetCountriesAsync(CancellationToken ct = default)
        {
            return await _cache.GetOrCreateAsync(CountriesCacheKey, async entry =>
            {
                entry.AbsoluteExpirationRelativeToNow =
                    TimeSpan.FromMinutes(_options.AbsoluteExpirationMinutes);
                entry.SlidingExpiration =
                    TimeSpan.FromMinutes(_options.SlidingExpirationMinutes);
                entry.Priority = CacheItemPriority.Normal;

                entry.RegisterPostEvictionCallback((key, value, reason, state) =>
                {
                    _logger.LogInformation("Cache evicted: {Key}, Reason: {Reason}", key, reason);
                });

                var countries = await _repo.LoadCountriesAsync(ct);
                _logger.LogInformation("Loaded countries from repository. Count = {Count}", countries.Count);
                return countries.AsReadOnly();
            });
        }

        public Task InvalidateCountriesAsync()
        {
            _cache.Remove(CountriesCacheKey);
            _logger.LogInformation("Manually invalidated countries cache");
            return Task.CompletedTask;
        }
    }
}
