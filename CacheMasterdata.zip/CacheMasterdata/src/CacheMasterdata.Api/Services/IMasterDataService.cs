using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace CacheMasterdata.Api.Services
{
    public interface IMasterDataService
    {
        Task<IReadOnlyList<string>> GetCountriesAsync(CancellationToken ct = default);
        Task InvalidateCountriesAsync();
    }
}
