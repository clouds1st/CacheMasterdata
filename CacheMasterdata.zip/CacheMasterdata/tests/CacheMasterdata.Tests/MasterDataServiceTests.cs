using CacheMasterdata.Api.Services;
using CacheMasterdata.Api.Settings;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Time.Testing;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace CacheMasterdata.Tests
{
    public class MasterDataServiceTests
    {
        private static IMemoryCache CreateMemoryCacheWithClock(FakeTimeProvider clock)
        {
            var options = new MemoryCacheOptions
            {
                Clock = clock
            };
            return new MemoryCache(options);
        }

        [Fact]
        public async Task GetCountriesAsync_PopulatesCache_ThenServesFromCache()
        {
            var clock = new FakeTimeProvider(DateTimeOffset.UtcNow);
            var cache = CreateMemoryCacheWithClock(clock);
            var repoMock = new Mock<IMasterDataRepository>();
            repoMock.Setup(r => r.LoadCountriesAsync(It.IsAny<CancellationToken>()))
                    .ReturnsAsync(new List<string> { "India", "USA", "UK" });

            var opts = Options.Create(new MasterDataCacheOptions
            {
                AbsoluteExpirationMinutes = 30,
                SlidingExpirationMinutes = 10
            });

            var service = new MasterDataService(cache, repoMock.Object, NullLogger<MasterDataService>.Instance, opts);

            var first = await service.GetCountriesAsync();
            var second = await service.GetCountriesAsync();

            Assert.NotNull(first);
            Assert.Equal(new[] { "India", "USA", "UK" }, first);
            Assert.Same(first, second);
            repoMock.Verify(r => r.LoadCountriesAsync(It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task InvalidateCountriesAsync_RemovesCache_TriggersRefetch()
        {
            var clock = new FakeTimeProvider(DateTimeOffset.UtcNow);
            var cache = CreateMemoryCacheWithClock(clock);
            var repoMock = new Mock<IMasterDataRepository>();

            var sequence = new Queue<List<string>>(new[]
            {
                new List<string> { "India", "USA" },
                new List<string> { "India", "USA", "UK" }
            });

            repoMock.Setup(r => r.LoadCountriesAsync(It.IsAny<CancellationToken>()))
                    .ReturnsAsync(() => sequence.Dequeue());

            var opts = Options.Create(new MasterDataCacheOptions
            {
                AbsoluteExpirationMinutes = 30,
                SlidingExpirationMinutes = 10
            });

            var service = new MasterDataService(cache, repoMock.Object, NullLogger<MasterDataService>.Instance, opts);

            var first = await service.GetCountriesAsync();
            await service.InvalidateCountriesAsync();
            var second = await service.GetCountriesAsync();

            Assert.Equal(new[] { "India", "USA" }, first);
            Assert.Equal(new[] { "India", "USA", "UK" }, second);
            repoMock.Verify(r => r.LoadCountriesAsync(It.IsAny<CancellationToken>()), Times.Exactly(2));
        }

        [Fact]
        public async Task GetCountriesAsync_ExpiresAfterAbsoluteExpiration_RefetchesFromRepo()
        {
            var start = DateTimeOffset.UtcNow;
            var clock = new FakeTimeProvider(start);
            var cache = CreateMemoryCacheWithClock(clock);
            var repoMock = new Mock<IMasterDataRepository>();
            repoMock.SetupSequence(r => r.LoadCountriesAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(new List<string> { "Germany", "France" })
                .ReturnsAsync(new List<string> { "Germany", "France", "Italy" });

            var opts = Options.Create(new MasterDataCacheOptions
            {
                AbsoluteExpirationMinutes = 1,
                SlidingExpirationMinutes = 1
            });

            var service = new MasterDataService(cache, repoMock.Object, NullLogger<MasterDataService>.Instance, opts);

            var first = await service.GetCountriesAsync();
            clock.Advance(TimeSpan.FromMinutes(1.5));
            var second = await service.GetCountriesAsync();

            Assert.Equal(new[] { "Germany", "France" }, first);
            Assert.Equal(new[] { "Germany", "France", "Italy" }, second);
            repoMock.Verify(r => r.LoadCountriesAsync(It.IsAny<CancellationToken>()), Times.Exactly(2));
        }
    }
}
